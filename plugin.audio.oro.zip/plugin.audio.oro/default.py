# -*- coding: utf-8 -*-
"""
Radios Colombia (Olimpica Stereo) - addon de radio para Kodi
Consulta en vivo la base de datos publica Radio Browser (radio-browser.info)
para obtener el stream real de cada emisora, en lugar de guardar una URL fija
que podria dejar de funcionar. Asi si Olimpica Stereo cambia de servidor,
el addon se sigue actualizando solo.
"""
import sys
import json
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Varios servidores espejo de Radio Browser, por si uno falla se prueba el siguiente
API_SERVERS = [
    "https://de1.api.radio-browser.info",
    "https://at1.api.radio-browser.info",
    "https://nl1.api.radio-browser.info",
    "https://all.api.radio-browser.info",
]

# Emisoras favoritas: (texto que ve el usuario, texto de busqueda en Radio Browser)
FAVORITES = [
    ("Olimpica Stereo Bogota", "Olimpica Stereo Bogota"),
    ("Olimpica Stereo Medellin", "Olimpica Stereo Medellin"),
    ("Olimpica Stereo Cali", "Olimpica Stereo Cali"),
    ("Olimpica Stereo Barranquilla", "Olimpica Stereo Barranquilla"),
    ("Olimpica Stereo Bucaramanga", "Olimpica Stereo Bucaramanga"),
    ("Olimpica Stereo Cartagena", "Olimpica Stereo Cartagena"),
    ("Olimpica Stereo Pereira", "Olimpica Stereo Pereira"),
    ("Olimpica Stereo Cucuta", "Olimpica Stereo Cucuta"),
    ("Olimpica Stereo Villavicencio", "Olimpica Stereo Villavicencio"),
    ("Olimpica Stereo Neiva", "Olimpica Stereo Neiva"),
    ("Radio Tiempo Colombia", "Radio Tiempo Colombia"),
    ("Caracol Radio", "Caracol Radio Colombia"),
    ("La Mega Colombia", "La Mega Colombia"),
    ("W Radio Colombia", "W Radio Colombia"),
    ("Blu Radio", "Blu Radio Colombia"),
]


def _http_get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "KodiRadiosColombia/1.0"})
    with urllib.request.urlopen(req, timeout=8) as resp:
        return json.loads(resp.read().decode("utf-8", errors="ignore"))


def api_get(path, params):
    query = urllib.parse.urlencode(params)
    last_error = None
    for server in API_SERVERS:
        url = "{0}{1}?{2}".format(server, path, query)
        try:
            return _http_get_json(url)
        except Exception as exc:  # noqa: BLE001 - queremos seguir probando servidores
            last_error = exc
            continue
    xbmc.log("RadiosColombia: fallo al consultar Radio Browser: {0}".format(last_error), xbmc.LOGWARNING)
    return []


def search_stations(name, limit=25):
    return api_get(
        "/json/stations/search",
        {
            "name": name,
            "limit": limit,
            "hidebroken": "true",
            "order": "votes",
            "reverse": "true",
        },
    )


def build_url(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def add_folder_item(label, url):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)


def add_playable_item(label, url, station=None):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    info = {"title": label}
    if station:
        if station.get("tags"):
            info["genre"] = station.get("tags")
        icon = station.get("favicon")
        if icon:
            li.setArt({"thumb": icon, "icon": icon})
    li.setInfo("music", info)
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=False)


def list_root():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Radios Colombia")
    xbmcplugin.setContent(ADDON_HANDLE, "songs")
    for label, query in FAVORITES:
        url = build_url(action="play_search", q=query)
        add_playable_item(label, url)
    add_folder_item("Buscar emisora por nombre...", build_url(action="search_prompt"))
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def search_prompt():
    kb = xbmc.Keyboard("", "Buscar emisora")
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        show_search_results(kb.getText())
        return
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def show_search_results(query):
    stations = search_stations(query, limit=30)
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Resultados: {0}".format(query))
    xbmcplugin.setContent(ADDON_HANDLE, "songs")
    if not stations:
        xbmcgui.Dialog().notification(
            "Sin resultados",
            "No se encontraron emisoras para '{0}'".format(query),
            xbmcgui.NOTIFICATION_INFO,
        )
    for st in stations:
        stream_url = st.get("url_resolved") or st.get("url")
        if not stream_url:
            continue
        country = st.get("country") or ""
        label = "{0} ({1})".format(st.get("name", "?"), country) if country else st.get("name", "?")
        add_playable_item(label, stream_url, station=st)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def play_from_search(query):
    stations = search_stations(query, limit=5)
    if not stations:
        xbmcgui.Dialog().notification(
            "Radios Colombia",
            "No se pudo encontrar '{0}' en este momento".format(query),
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        return
    station = stations[0]
    stream_url = station.get("url_resolved") or station.get("url")
    li = xbmcgui.ListItem(label=station.get("name"), path=stream_url)
    icon = station.get("favicon")
    if icon:
        li.setArt({"thumb": icon, "icon": icon})
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    if action == "search_prompt":
        search_prompt()
    elif action == "search_results":
        show_search_results(params.get("q", ""))
    elif action == "play_search":
        play_from_search(params.get("q", ""))
    else:
        list_root()


if __name__ == "__main__":
    router(sys.argv[2][1:])
