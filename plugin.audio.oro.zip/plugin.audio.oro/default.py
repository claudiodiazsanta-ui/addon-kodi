# -*- coding: utf-8 -*-
"""
Radios Colombia (Olímpica Stereo) - punto de entrada del addon.

Siguiendo la convencion oficial de addons de Kodi, este archivo es solo un
lanzador delgado: toda la logica real vive organizada en resources/lib/
(radio_api.py para los datos, ui.py para las pantallas, settings.py para
los ajustes del usuario). Ver: https://kodi.wiki/view/Add-on_structure
"""
import sys

from resources.lib import ui


def main():
    router_param = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    ui.router(router_param)


if __name__ == "__main__":
    main()
