# -*- coding: utf-8 -*-
"""
Datos basicos que Kodi entrega al arrancar el plugin. Se calculan una sola
vez aqui y el resto de los modulos los importan, para no repetir
sys.argv[...] por todo el codigo.
"""
import sys

import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

# sys.argv solo tiene el formato completo (handle, url base, querystring)
# cuando Kodi ejecuta el addon como plugin. Si alguna vez se importa este
# modulo fuera de ese contexto (por ejemplo en pruebas unitarias), no debe
# reventar con un IndexError.
if len(sys.argv) >= 2:
    ADDON_HANDLE = int(sys.argv[1])
    BASE_URL = sys.argv[0]
else:
    ADDON_HANDLE = -1
    BASE_URL = "plugin://{0}/".format(ADDON_ID)
