# -*- coding: utf-8 -*-
"""
Capa de interfaz: construye los menús de Kodi y resuelve la reproducción.
No contiene llamadas de red directas -- todo eso vive en radio_api.py.
"""
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.kodi_env import ADDON_HANDLE, BASE_URL
from resources.lib.settings import get_only_colombia
from resources.lib import radio_api


def build_url(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def add_folder_item(label, url, icon=None, context_menu=None):
    li = xbmcgui.ListItem(label=label)
    if icon:
        li.setArt({"thumb": icon, "icon": icon})
    if context_menu:
        li.addContextMenuItems(context_menu)
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)


def _play_now(stream_url, name, icon):
    """
    Ordena la reproducción directamente con xbmc.Player(), en vez de dejar
    que Kodi la resuelva como parte de una lista navegable.

    Por qué: cuando un item se reproduce a través del mecanismo normal de
    "tocar un item reproducible dentro de una carpeta", Kodi arma una cola
    con el resto de los items de esa carpeta y, si uno falla, salta solo al
    siguiente sin avisar claramente -- así sonaba una emisora distinta a la
    que realmente se tocó. Quitar el content type "songs" no fue suficiente
    para evitarlo (depende también de un ajuste general de Kodi). Llamando
    a xbmc.Player().play() directamente, por fuera de ese mecanismo de
    carpeta/cola, la única emisora que se reproduce es esta.
    """
    if stream_url:
        li = xbmcgui.ListItem(label=name or stream_url)
        li.setPath(stream_url)
        if icon:
            li.setArt({"thumb": icon, "icon": icon})
        li.setProperty("IsLive", "true")
        li.setInfo("music", {"title": name or stream_url})
        li.setMimeType(radio_api.guess_mimetype(stream_url))
        li.setContentLookup(False)
        xbmc.Player().play(stream_url, li)
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)
        return True

    xbmcgui.Dialog().notification(
        "Radios Colombia",
        "'{0}' no respondió en este momento.".format(name or "Emisora"),
        xbmcgui.NOTIFICATION_ERROR,
    )
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
    return False


def list_root():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Radios Colombia")
    # A propósito, cada emisora se agrega como item de "carpeta" (isFolder=True)
    # en vez de item reproducible de lista -- ver _play_now() para el porqué.

    busy = xbmcgui.DialogProgressBG()
    busy.create("Radios Colombia", "Verificando emisoras...")
    total = len(radio_api.FAVORITES)
    for idx, (label, query) in enumerate(radio_api.FAVORITES):
        busy.update(int(100 * idx / total), message=label)
        station = radio_api.resolve_favorite(query, display_name=label)
        url = build_url(action="play_favorite", q=query, n=label)
        repair_cmd = "RunPlugin({0})".format(build_url(action="refresh_one", q=query, n=label))
        ctx = [("Reparar solo esta emisora", repair_cmd)]
        if station and station.get("alive"):
            add_folder_item("\u25b6 {0}".format(label), url, icon=station.get("favicon"), context_menu=ctx)
        else:
            add_folder_item(
                "\u26a0 {0} (sin señal, toca para reintentar)".format(label), url, context_menu=ctx
            )
    busy.close()

    add_folder_item("Buscar emisora por nombre...", build_url(action="search_prompt"))
    add_folder_item("\U0001F504 Verificar y reparar todos los enlaces", build_url(action="refresh_all"))
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def refresh_all():
    busy = xbmcgui.DialogProgressBG()
    busy.create("Radios Colombia", "Revisando todas las emisoras...")
    total = len(radio_api.FAVORITES)
    fixed, broken = 0, 0
    for idx, (label, query) in enumerate(radio_api.FAVORITES):
        busy.update(int(100 * idx / total), message=label)
        station = radio_api.resolve_favorite(query, force=True, display_name=label)
        if station and station.get("alive"):
            fixed += 1
        else:
            broken += 1
    busy.close()
    xbmcgui.Dialog().notification(
        "Radios Colombia",
        "{0} emisoras funcionando, {1} sin señal".format(fixed, broken),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmcplugin.endOfDirectory(ADDON_HANDLE, updateListing=True)


def refresh_one(query, display_name=None):
    """Repara solo una emisora (se llama desde el menu contextual)."""
    station = radio_api.resolve_favorite(query, force=True, display_name=display_name)
    if station and station.get("alive"):
        xbmcgui.Dialog().notification(
            "Radios Colombia", "{0}: enlace reparado".format(station.get("name", display_name or query)),
            xbmcgui.NOTIFICATION_INFO,
        )
    else:
        xbmcgui.Dialog().notification(
            "Radios Colombia", "{0}: sigue sin responder ninguna fuente".format(display_name or query),
            xbmcgui.NOTIFICATION_ERROR,
        )
    xbmcplugin.endOfDirectory(ADDON_HANDLE, updateListing=True)


def search_prompt():
    kb = xbmc.Keyboard("", "Buscar emisora")
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        show_search_results(kb.getText())
        return
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def show_search_results(query):
    stations = radio_api.search_stations(query, limit=30)
    if get_only_colombia():
        stations = [st for st in stations if (st.get("country") or "").strip().lower() == "colombia"]

    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Resultados: {0}".format(query))
    if not stations:
        xbmcgui.Dialog().notification(
            "Sin resultados", "No se encontraron emisoras para '{0}'".format(query),
            xbmcgui.NOTIFICATION_INFO,
        )
    for st in stations:
        stream_url = st.get("url_resolved") or st.get("url")
        if not stream_url:
            continue
        country = st.get("country") or ""
        label = "{0} ({1})".format(st.get("name", "?"), country) if country else st.get("name", "?")
        play_url = build_url(action="play_direct", u=stream_url, n=st.get("name", "?"), i=st.get("favicon", ""))
        add_folder_item("\u25b6 {0}".format(label), play_url, icon=st.get("favicon"))
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def play_direct(stream_url, name, icon):
    """Reproduce una URL ya conocida de una busqueda previa."""
    if stream_url and radio_api.stream_is_alive(stream_url):
        _play_now(stream_url, name, icon)
    else:
        _play_now(None, name, icon)


def play_from_search(query):
    """Ruta de respaldo: busca por nombre y reproduce el primer resultado vivo."""
    stations = radio_api.search_stations(query, limit=5)
    for station in stations:
        stream_url = station.get("url_resolved") or station.get("url")
        if stream_url and radio_api.stream_is_alive(stream_url):
            _play_now(stream_url, station.get("name"), station.get("favicon"))
            return
    _play_now(None, query, None)


def play_favorite(query, display_name=None):
    """
    Reproduce una emisora favorita usando el enlace en cache si esta vivo;
    si está caída o venció el caché, reintenta en vivo (repara el enlace solo).
    """
    station = radio_api.resolve_favorite(query, display_name=display_name)
    if not station or not station.get("alive"):
        station = radio_api.resolve_favorite(query, force=True, display_name=display_name)

    if not station or not station.get("alive") or not station.get("url"):
        xbmcgui.Dialog().notification(
            "Radios Colombia",
            "{0}: enlace roto. Prueba 'Verificar y reparar' en el menú.".format(display_name or query),
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    _play_now(station["url"], station.get("name", display_name or query), station.get("favicon"))


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    try:
        if action == "search_prompt":
            search_prompt()
        elif action == "search_results":
            show_search_results(params.get("q", ""))
        elif action == "play_search":
            play_from_search(params.get("q", ""))
        elif action == "play_favorite":
            play_favorite(params.get("q", ""), params.get("n", ""))
        elif action == "play_direct":
            play_direct(params.get("u", ""), params.get("n", ""), params.get("i", ""))
        elif action == "refresh_all":
            refresh_all()
        elif action == "refresh_one":
            refresh_one(params.get("q", ""), params.get("n", ""))
        else:
            list_root()
    except Exception as exc:  # noqa: BLE001
        # Blindaje final: pase lo que pase, Kodi nunca se queda con el menu
        # "colgado" en silencio -- siempre se avisa y se cierra limpio.
        xbmc.log("RadiosColombia: ERROR en accion '{0}': {1}".format(action, exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "Radios Colombia", "Ocurrió un error inesperado. Revisa el log de Kodi.",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
