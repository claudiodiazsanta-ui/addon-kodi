# -*- coding: utf-8 -*-
"""
Todo lo que habla con el mundo exterior: la API pública de Radio Browser
(radio-browser.info) y la verificación real de que un stream responde.
Este módulo no toca xbmcgui/xbmcplugin a propósito -- es lógica pura,
mas fácil de razonar y de probar por separado de la parte de interfaz.
"""
import json
import os
import socket
import time
import unicodedata
import urllib.parse
import urllib.request

import xbmc
import xbmcvfs

from resources.lib.kodi_env import ADDON
from resources.lib.settings import get_cache_ttl_seconds, get_stream_check_timeout

# Varios servidores espejo de Radio Browser, por si uno falla se prueba el siguiente
API_SERVERS = [
    "https://de1.api.radio-browser.info",
    "https://at1.api.radio-browser.info",
    "https://nl1.api.radio-browser.info",
    "https://all.api.radio-browser.info",
]

# Emisoras favoritas: (texto que ve el usuario, texto de busqueda en Radio Browser)
FAVORITES = [
    ("Olímpica Stereo Bogotá", "Olimpica Stereo Bogota"),
    ("Olímpica Stereo Medellín", "Olimpica Stereo Medellin"),
    ("Olímpica Stereo Cali", "Olimpica Stereo Cali"),
    ("Olímpica Stereo Barranquilla", "Olimpica Stereo Barranquilla"),
    ("Olímpica Stereo Bucaramanga", "Olimpica Stereo Bucaramanga"),
    ("Olímpica Stereo Cartagena", "Olimpica Stereo Cartagena"),
    ("Olímpica Stereo Pereira", "Olimpica Stereo Pereira"),
    ("Olímpica Stereo Cúcuta", "Olimpica Stereo Cucuta"),
    ("Olímpica Stereo Villavicencio", "Olimpica Stereo Villavicencio"),
    ("Olímpica Stereo Neiva", "Olimpica Stereo Neiva"),
    ("Radio Tiempo Colombia", "Radio Tiempo Colombia"),
    ("Caracol Radio", "Caracol Radio Colombia"),
    ("La Mega Colombia", "La Mega Colombia"),
    ("W Radio Colombia", "W Radio Colombia"),
    ("Blu Radio", "Blu Radio Colombia"),
]

MAX_CANDIDATES_TO_TRY = 8  # cuantas emisoras candidatas probar antes de rendirse
USER_AGENT = "KodiRadiosColombia/1.5.0 (+https://github.com)"

# --------------------------------------------------------------------------
# Enlaces "oficiales" conocidos, en la red profesional StreamTheWorld
# (Triton Digital) que usa Olimpica Stereo y varias grandes cadenas
# colombianas. Se prueban ANTES que Radio Browser porque son muchísimo mas
# estables que servidores comunitarios sueltos -- si algún dia cambian de
# callsign y dejan de responder, el codigo cae de vuelta a Radio Browser
# automaticamente, así que no hay ningun riesgo por incluirlos.
#
# Confirmados directamente (encontrados citados en directorios de radio):
# Bogota, Medellin, Barranquilla, Pereira, Caracol Radio.
# El resto de ciudades de Olimpica sigue el mismo patron exacto en las 6
# ciudades que se pudieron confirmar (OLP_<CIUDAD>AAC), así que se incluyen
# por el mismo patron -- si alguna no es correcta, simplemente no se usa y
# se sigue con la busqueda normal, sin ningun efecto negativo.
_STREAMTHEWORLD_BASE = "https://playerservices.streamtheworld.com/api/livestream-redirect/{0}.aac"

OFFICIAL_STREAMS = {
    "Olimpica Stereo Bogota": _STREAMTHEWORLD_BASE.format("OLP_BOGOTAAAC"),
    "Olimpica Stereo Medellin": _STREAMTHEWORLD_BASE.format("OLP_MEDELLINAAC"),
    "Olimpica Stereo Barranquilla": _STREAMTHEWORLD_BASE.format("OLP_BARRANQUILLAAAC"),
    "Olimpica Stereo Pereira": _STREAMTHEWORLD_BASE.format("OLP_PEREIRAAAC"),
    "Olimpica Stereo Cali": _STREAMTHEWORLD_BASE.format("OLP_CALIAAC"),
    "Olimpica Stereo Bucaramanga": _STREAMTHEWORLD_BASE.format("OLP_BUCARAMANGAAAC"),
    "Olimpica Stereo Cartagena": _STREAMTHEWORLD_BASE.format("OLP_CARTAGENAAAC"),
    "Olimpica Stereo Cucuta": _STREAMTHEWORLD_BASE.format("OLP_CUCUTAAAC"),
    "Olimpica Stereo Villavicencio": _STREAMTHEWORLD_BASE.format("OLP_VILLAVICENCIOAAC"),
    "Olimpica Stereo Neiva": _STREAMTHEWORLD_BASE.format("OLP_NEIVAAAC"),
    "Caracol Radio Colombia": _STREAMTHEWORLD_BASE.format("CARACOL_RADIOAAC"),
}

# Si cambia la lógica de que significa "vivo" (como en 1.3.1, donde se
# arregló la detección de streams ICY/Shoutcast), hay que subir este número.
# Al no coincidir con el guardado en el archivo de cache, se descarta todo
# lo viejo automáticamente -- así el usuario no se queda viendo "sin señal"
# por horas con datos calculados con la lógica vieja y ya corregida.
CACHE_SCHEMA_VERSION = 4


# --------------------------------------------------------------------------
# Cache en disco (perfil del addon), para no tener que revalidar todo cada
# vez que se abre el menu.
# --------------------------------------------------------------------------

def _cache_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "stations_cache.json")


def _load_cache():
    path = _cache_path()
    if not xbmcvfs.exists(path):
        return {}
    try:
        f = xbmcvfs.File(path)
        data = f.read()
        f.close()
        parsed = json.loads(data) if data else {}
        if parsed.get("_schema") != CACHE_SCHEMA_VERSION:
            # Cache de una versión anterior con lógica de validación distinta:
            # se descarta entera para no arrastrar "sin señal" incorrectos.
            return {}
        return parsed
    except Exception:
        return {}


def _save_cache(cache):
    try:
        cache["_schema"] = CACHE_SCHEMA_VERSION
        f = xbmcvfs.File(_cache_path(), "w")
        f.write(json.dumps(cache))
        f.close()
    except Exception as exc:  # noqa: BLE001
        xbmc.log("RadiosColombia: no se pudo guardar cache: {0}".format(exc), xbmc.LOGWARNING)


# --------------------------------------------------------------------------
# Radio Browser API
# --------------------------------------------------------------------------

def _http_get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=8) as resp:
        return json.loads(resp.read().decode("utf-8", errors="ignore"))


def api_get(path, params):
    query = urllib.parse.urlencode(params)
    last_error = None
    for server in API_SERVERS:
        url = "{0}{1}?{2}".format(server, path, query)
        try:
            return _http_get_json(url)
        except Exception as exc:  # noqa: BLE001 - seguimos probando el siguiente servidor
            last_error = exc
            continue
    xbmc.log("RadiosColombia: fallo al consultar Radio Browser: {0}".format(last_error), xbmc.LOGWARNING)
    return []


def strip_accents(text):
    """Quita tildes/diacriticos: 'Olímpica' -> 'Olimpica'."""
    if not text:
        return text
    normalized = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in normalized if not unicodedata.combining(ch))


def _search_stations_raw(name, limit):
    return api_get(
        "/json/stations/search",
        {
            "name": name,
            "limit": limit,
            "hidebroken": "true",
            "order": "votes",
            "reverse": "true",
        },
    )


def search_stations(name, limit=25):
    """
    Busca por nombre. La API no siempre normaliza tildes, así que si la
    busqueda exacta no trae nada, reintenta con/sin acentos, para que
    'Olímpica' y 'Olimpica' encuentren lo mismo.
    """
    results = _search_stations_raw(name, limit)
    if results:
        return results

    alt_name = strip_accents(name)
    if alt_name and alt_name != name:
        results = _search_stations_raw(alt_name, limit)
    return results


def guess_mimetype(url):
    lowered = (url or "").lower().split("?")[0]
    if lowered.endswith(".m3u8"):
        return "application/vnd.apple.mpegurl"
    if lowered.endswith(".aac"):
        return "audio/aac"
    if lowered.endswith(".ogg"):
        return "audio/ogg"
    return "audio/mpeg"


def _tcp_reachable(url, timeout):
    """
    Verificación de bajo nivel: ¿el servidor siquiera acepta una conexión en
    ese host y puerto? No se envia ninguna petición HTTP ni se lee ninguna
    respuesta -- a propósito. Intentar hablar el protocolo HTTP/ICY nosotros
    mismos (como en versiones anteriores) resultó ser fragil: muchos
    servidores de radio bloquean peticiones que no vengan de un reproductor
    "reconocido" por su User-Agent, o responden distinto según el cliente.
    Kodi, al reproducir de verdad, sí es reconocido como un reproductor real
    y consigue conectar donde una sonda casera de Python no puede. Por eso
    aquí solo confirmamos que la puerta esta abierta (TCP), y confiamos en
    los datos que ya trae Radio Browser (que monitorea las emisoras de forma
    profesional) para decidir cual URL es probablemente buena.
    """
    try:
        parsed = urllib.parse.urlsplit(url)
        host = parsed.hostname
        if not host:
            return False
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        with socket.create_connection((host, port), timeout=timeout):
            pass
        return True
    except Exception:
        return False


def stream_is_alive(url, timeout=None):
    """
    Confirma que el host de la emisora acepta conexiones. No valida el
    contenido de la respuesta (ver _tcp_reachable) porque replicar el
    protocolo de streaming en Python resultó mas fragil que el propio
    reproductor de Kodi. Esta comprobacion existe para descartar casos
    claramente muertos (dominio caído, DNS que no resuelve, puerto cerrado),
    no para garantizar que el audio en si va a sonar -- eso lo decide Kodi
    al reproducir.
    """
    timeout = timeout or get_stream_check_timeout()
    if not url:
        return False
    return _tcp_reachable(url, timeout)


def _http_ok(url, timeout):
    """
    Verificación HTTP normal, para endpoints modernos y estándar como la API
    de redirección de StreamTheWorld (a diferencia de los servidores
    Shoutcast/Icecast comunitarios de Radio Browser, que resultaron
    demasiado variados para validar bien con HTTP puro -- ver _tcp_reachable).
    """
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read(64)
        return True
    except Exception:
        return False


def _candidate_sort_key(station):
    # Preferimos primero las que Radio Browser marco como "última vez que
    # la revisamos, funcionaba" (lastcheckok), y entre esas, las mas votadas.
    lastcheckok = station.get("lastcheckok")
    ok = 1 if lastcheckok in (1, "1", True) else 0
    votes = station.get("votes") or 0
    return (ok, votes)


def resolve_favorite(query, force=False):
    """
    Busca una emisora favorita, prueba varios candidatos hasta encontrar uno
    que realmente responda, y cachea el resultado. Devuelve un dict:
    {name, url, favicon, alive, checked_at}.

    Orden de prioridad:
    1. Enlace oficial conocido (StreamTheWorld), si existe para esta emisora
       y responde -- es la fuente mas estable.
    2. Candidatos de Radio Browser, ordenados por su propio historial de
       monitoreo (lastcheckok) y votos.
    """
    cache = _load_cache()
    entry = cache.get(query)
    now = time.time()

    if not force and entry and entry.get("alive") and (now - entry.get("checked_at", 0)) < get_cache_ttl_seconds():
        return entry

    timeout = get_stream_check_timeout()

    official_url = OFFICIAL_STREAMS.get(query)
    if official_url and _http_ok(official_url, timeout):
        result = {
            "name": query,
            "url": official_url,
            "favicon": "",
            "alive": True,
            "checked_at": now,
        }
        cache[query] = result
        _save_cache(cache)
        return result

    candidates = search_stations(query, limit=MAX_CANDIDATES_TO_TRY)
    candidates = sorted(candidates, key=_candidate_sort_key, reverse=True)
    for st in candidates:
        stream_url = st.get("url_resolved") or st.get("url")
        if not stream_url:
            continue
        if stream_is_alive(stream_url):
            result = {
                "name": st.get("name") or query,
                "url": stream_url,
                "favicon": st.get("favicon") or "",
                "alive": True,
                "checked_at": now,
            }
            cache[query] = result
            _save_cache(cache)
            return result

    # Nada respondio: guardamos que esta caida (se reintenta en la proxima visita)
    result = {"name": query, "url": "", "favicon": "", "alive": False, "checked_at": now}
    cache[query] = result
    _save_cache(cache)
    return result
