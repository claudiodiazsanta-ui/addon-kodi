# -*- coding: utf-8 -*-
"""
Todo lo que habla con el mundo exterior: la API pública de Radio Browser
(radio-browser.info) y la verificación real de que un stream responde.
Este módulo no toca xbmcgui/xbmcplugin a propósito -- es lógica pura,
mas fácil de razonar y de probar por separado de la parte de interfaz.
"""
import http.client
import json
import os
import socket
import ssl
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcvfs

from resources.lib.kodi_env import ADDON
from resources.lib.settings import get_cache_ttl_seconds, get_stream_check_timeout

# Varios servidores espejo de Radio Browser, por si uno falla se prueba el siguiente
API_SERVERS = [
    "https://de1.api.radio-browser.info",
    "https://at1.api.radio-browser.info",
    "https://nl1.api.radio-browser.info",
    "https://all.api.radio-browser.info",
]

# Emisoras favoritas: (texto que ve el usuario, texto de busqueda en Radio Browser)
FAVORITES = [
    ("Olímpica Stereo Bogotá", "Olimpica Stereo Bogota"),
    ("Olímpica Stereo Medellín", "Olimpica Stereo Medellin"),
    ("Olímpica Stereo Cali", "Olimpica Stereo Cali"),
    ("Olímpica Stereo Barranquilla", "Olimpica Stereo Barranquilla"),
    ("Olímpica Stereo Bucaramanga", "Olimpica Stereo Bucaramanga"),
    ("Olímpica Stereo Cartagena", "Olimpica Stereo Cartagena"),
    ("Olímpica Stereo Pereira", "Olimpica Stereo Pereira"),
    ("Olímpica Stereo Cúcuta", "Olimpica Stereo Cucuta"),
    ("Olímpica Stereo Villavicencio", "Olimpica Stereo Villavicencio"),
    ("Olímpica Stereo Neiva", "Olimpica Stereo Neiva"),
    ("Radio Tiempo Colombia", "Radio Tiempo Colombia"),
    ("Caracol Radio", "Caracol Radio Colombia"),
    ("La Mega Colombia", "La Mega Colombia"),
    ("W Radio Colombia", "W Radio Colombia"),
    ("Blu Radio", "Blu Radio Colombia"),
]

MAX_CANDIDATES_TO_TRY = 5  # cuantas emisoras candidatas probar antes de rendirse
USER_AGENT = "KodiRadiosColombia/1.3.2 (+https://github.com)"

# Si cambia la lógica de que significa "vivo" (como en 1.3.1, donde se
# arreglo la detección de streams ICY/Shoutcast), hay que subir este número.
# Al no coincidir con el guardado en el archivo de cache, se descarta todo
# lo viejo automáticamente -- así el usuario no se queda viendo "sin señal"
# por horas con datos calculados con la lógica vieja y ya corregida.
CACHE_SCHEMA_VERSION = 2


# --------------------------------------------------------------------------
# Cache en disco (perfil del addon), para no tener que revalidar todo cada
# vez que se abre el menu.
# --------------------------------------------------------------------------

def _cache_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "stations_cache.json")


def _load_cache():
    path = _cache_path()
    if not xbmcvfs.exists(path):
        return {}
    try:
        f = xbmcvfs.File(path)
        data = f.read()
        f.close()
        parsed = json.loads(data) if data else {}
        if parsed.get("_schema") != CACHE_SCHEMA_VERSION:
            # Cache de una versión anterior con lógica de validación distinta:
            # se descarta entera para no arrastrar "sin señal" incorrectos.
            return {}
        return parsed
    except Exception:
        return {}


def _save_cache(cache):
    try:
        cache["_schema"] = CACHE_SCHEMA_VERSION
        f = xbmcvfs.File(_cache_path(), "w")
        f.write(json.dumps(cache))
        f.close()
    except Exception as exc:  # noqa: BLE001
        xbmc.log("RadiosColombia: no se pudo guardar cache: {0}".format(exc), xbmc.LOGWARNING)


# --------------------------------------------------------------------------
# Radio Browser API
# --------------------------------------------------------------------------

def _http_get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=8) as resp:
        return json.loads(resp.read().decode("utf-8", errors="ignore"))


def api_get(path, params):
    query = urllib.parse.urlencode(params)
    last_error = None
    for server in API_SERVERS:
        url = "{0}{1}?{2}".format(server, path, query)
        try:
            return _http_get_json(url)
        except Exception as exc:  # noqa: BLE001 - seguimos probando el siguiente servidor
            last_error = exc
            continue
    xbmc.log("RadiosColombia: fallo al consultar Radio Browser: {0}".format(last_error), xbmc.LOGWARNING)
    return []


def strip_accents(text):
    """Quita tildes/diacriticos: 'Olímpica' -> 'Olimpica'."""
    if not text:
        return text
    normalized = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in normalized if not unicodedata.combining(ch))


def _search_stations_raw(name, limit):
    return api_get(
        "/json/stations/search",
        {
            "name": name,
            "limit": limit,
            "hidebroken": "true",
            "order": "votes",
            "reverse": "true",
        },
    )


def search_stations(name, limit=25):
    """
    Busca por nombre. La API no siempre normaliza tildes, así que si la
    busqueda exacta no trae nada, reintenta con/sin acentos, para que
    'Olímpica' y 'Olimpica' encuentren lo mismo.
    """
    results = _search_stations_raw(name, limit)
    if results:
        return results

    alt_name = strip_accents(name)
    if alt_name and alt_name != name:
        results = _search_stations_raw(alt_name, limit)
    return results


def guess_mimetype(url):
    lowered = (url or "").lower().split("?")[0]
    if lowered.endswith(".m3u8"):
        return "application/vnd.apple.mpegurl"
    if lowered.endswith(".aac"):
        return "audio/aac"
    if lowered.endswith(".ogg"):
        return "audio/ogg"
    return "audio/mpeg"


def _raw_icy_check(url, timeout):
    """
    Verificacion de bajo nivel para servidores Shoutcast clasicos que
    responden 'ICY 200 OK' en vez de 'HTTP/1.1 200 OK'. La libreria
    estándar de Python (urllib/http.client) rechaza esa respuesta con un
    error de 'BadStatusLine' aunque el stream funciona perfectamente --
    Kodi sí sabe reproducirlo. Aqui hablamos el protocolo a mano con un
    socket crudo para no depender de que la respuesta sea HTTP valido.
    """
    try:
        parsed = urllib.parse.urlsplit(url)
        host = parsed.hostname
        if not host:
            return False
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query

        sock = socket.create_connection((host, port), timeout=timeout)
        try:
            if parsed.scheme == "https":
                context = ssl.create_default_context()
                sock = context.wrap_socket(sock, server_hostname=host)
            request = (
                "GET {0} HTTP/1.0\r\n"
                "Host: {1}\r\n"
                "User-Agent: {2}\r\n"
                "Icy-MetaData: 1\r\n"
                "Connection: close\r\n\r\n"
            ).format(path, host, USER_AGENT)
            sock.sendall(request.encode("ascii", errors="ignore"))
            data = sock.recv(512)
        finally:
            sock.close()

        if not data:
            return False
        first_line = data.split(b"\r\n", 1)[0]
        # Cualquiera de las dos lineas de estado cuenta como "el servidor esta ahi
        # y responde como una radio" -- HTTP estándar o ICY (Shoutcast clasico).
        return first_line.startswith(b"HTTP/") or first_line.startswith(b"ICY")
    except Exception:
        return False


def stream_is_alive(url, timeout=None):
    """
    Prueba de verdad si el stream responde, no solo si la URL existe.
    Primero intenta con urllib (rápido y maneja https/redirecciones bien
    para servidores modernos). Si urllib falla porque el servidor respondio
    algo que no es HTTP valido (tipico de Shoutcast clasico, 'ICY 200 OK'),
    reintenta con un socket crudo tolerante a ese protocolo -- Kodi sí sabe
    reproducirlo aunque Python no sepa parsearlo.
    Si en cambio la falla es de red (no conecta, host caido, timeout de
    conexión), no tiene sentido reintentar: seria la misma conexión
    fallando dos veces y solo duplicaria la espera para nada.
    """
    timeout = timeout or get_stream_check_timeout()
    if not url:
        return False
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": USER_AGENT, "Icy-MetaData": "1"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read(256)
        return True
    except http.client.HTTPException:
        # La conexión SI se establecio, pero la respuesta no es HTTP
        # estándar (ej. 'ICY 200 OK'). Vale la pena verificar a mano.
        return _raw_icy_check(url, timeout)
    except (urllib.error.URLError, OSError):
        # Fallo de red real (DNS, conexión rechazada, timeout de conexión):
        # reintentar con el mismo host/puerto no va a cambiar el resultado.
        return False


def resolve_favorite(query, force=False):
    """
    Busca una emisora favorita, prueba varios candidatos hasta encontrar uno
    que realmente responda, y cachea el resultado. Devuelve un dict:
    {name, url, favicon, alive, checked_at}.
    """
    cache = _load_cache()
    entry = cache.get(query)
    now = time.time()

    if not force and entry and entry.get("alive") and (now - entry.get("checked_at", 0)) < get_cache_ttl_seconds():
        return entry

    candidates = search_stations(query, limit=MAX_CANDIDATES_TO_TRY)
    for st in candidates:
        stream_url = st.get("url_resolved") or st.get("url")
        if not stream_url:
            continue
        if stream_is_alive(stream_url):
            result = {
                "name": st.get("name") or query,
                "url": stream_url,
                "favicon": st.get("favicon") or "",
                "alive": True,
                "checked_at": now,
            }
            cache[query] = result
            _save_cache(cache)
            return result

    # Nada respondio: guardamos que esta caida (se reintenta en la proxima visita)
    result = {"name": query, "url": "", "favicon": "", "alive": False, "checked_at": now}
    cache[query] = result
    _save_cache(cache)
    return result
