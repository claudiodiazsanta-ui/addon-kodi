# -*- coding: utf-8 -*-
"""Lectura de los ajustes configurables por el usuario (resources/settings.xml)."""
from resources.lib.kodi_env import ADDON

CACHE_HOURS_DEFAULT = 12
CHECK_TIMEOUT_DEFAULT = 5


def get_cache_ttl_seconds():
    try:
        hours = ADDON.getSettingInt("cache_hours")
        return (hours or CACHE_HOURS_DEFAULT) * 60 * 60
    except Exception:
        return CACHE_HOURS_DEFAULT * 60 * 60


def get_stream_check_timeout():
    try:
        return ADDON.getSettingInt("check_timeout") or CHECK_TIMEOUT_DEFAULT
    except Exception:
        return CHECK_TIMEOUT_DEFAULT


def get_only_colombia():
    try:
        return ADDON.getSettingBool("only_colombia")
    except Exception:
        return False
